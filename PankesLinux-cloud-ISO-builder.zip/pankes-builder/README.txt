PANKES LINUX - CLOUD ISO BUILDER

This package adds a GitHub Actions workflow that builds a minimal x86_64
BIOS/UEFI bootable Pankes Linux command-line ISO in GitHub's Ubuntu runner.
It does not create the graphical desktop environment yet.

INSTALL:
1. Extract this ZIP.
2. Upload the .github folder to the root of your GitHub repository
   (1kaanpro2017-cloud/PankesLinux-Turkish), preserving the folder structure.
3. Open the repository's Actions tab.
4. Select "Build Pankes Linux ISO" and click "Run workflow".
5. When the run succeeds, download PankesLinux-x86_64-ISO from Artifacts.

NOTES:
- GitHub Actions must be enabled for the repository.
- The workflow downloads Linux kernel 6.12.63 and installs required packages
  on the hosted Ubuntu runner (including xorriso, GRUB, mtools, dosfstools).
- This is a minimal live command-line system, not the finished Pankes desktop.
- The workflow has not been run or verified in this session.
